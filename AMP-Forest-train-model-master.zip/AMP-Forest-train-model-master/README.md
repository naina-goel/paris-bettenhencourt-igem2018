The software is developd by iGEM team Paris Bettencourt 2018.

AMP Forest training folder contains all the files including the NGS data used for training, to rebuild the AMP Forest, with different parameters, such as the tree numbers as you want.

AMP Designer folder contains the AMP Designer.m file, and supporting mat datasets, where user could define parameters, and also edit functions. AMP Designer is mainly used to create better AMP sequences in silico.

Please properly use the code and software based on the license.
